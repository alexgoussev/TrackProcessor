int main(void)
{
    /* Initialized data */
    static double x[5] = { 1.,2.,3.,4.,5. };
    static double f[5] = { 1.,4.,20.,16.,25. };
    static double df[5] = { .2,.2,10.,.2,.2 };

    /* Builtin functions */
    double sqrt(double);

    /* Local variables */
    extern int is01d_c(double *, double *, double *, int *, double *,
                       double *, double *, double *, int *);
    static int ierr;
    static double c__[12]   /* was [3][4] */;
    static int i__;
    static double y[5], sm;
    static int nx;
    static double rab[49]   /* was [7][7] */;

#define c___ref(a_1,a_2) c__[(a_2)*3 + a_1]

    nx = 5;
    sm = (double) ((float) nx) - 1. - sqrt((double) ((float) (nx + nx)));
    is01d_c(x, f, df, &nx, &sm, y, c__, rab, &ierr);

    printf("\n %5i \n",ierr);
    for (i__ = 1; i__ <= 5; ++i__) {
           printf("\n %24.14e \n",y[i__-1]);
    }
    for (i__ = 0; i__ < 3; ++i__) {
        printf("\n %24.14e %24.14e \n %24.14e %24.14e \n",
          c___ref(i__, 0), c___ref(i__, 1), c___ref(i__, 2), c___ref(i__, 3));
        }
    return 0;
} /* main */

#undef c___ref
