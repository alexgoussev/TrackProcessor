#include <stdio.h>
#include "smoothedspline.h"

int main()
{
  static double x[5] = { 1.,2.,3.,4.,5. };
  static double f[5] = { 1.,4.,20.,16.,25. };
  static double df[5] = { .2,.2,10.,.2,.2 };
  SmoothedSpline *pSpline = new SmoothedSpline;

  pSpline->Create(5, x, f, df);
  double *pSY = pSpline->SmoothedY();

  if(pSY)
  {
    for(int i = 0; i < 5; i++)
      printf("%10.6lf\n", pSY[i]);
  }

  delete pSpline;

  return 0;
}
