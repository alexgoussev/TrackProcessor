#include <stdio.h>
#include "spline3.h"

int main()
{
  ap::real_1d_array x;
  ap::real_1d_array y;
  ap::real_1d_array c1;
  ap::real_1d_array c2;
  ap::real_1d_array c3;
  int n = 5;
  
  x.setbounds(0, n - 1);
  y.setbounds(0, n - 1);
  
  x(0) = 1; x(1) = 2; x(2) = 3; x(3) = 4; x(4) = 5;
  y(0) = 1; y(1) = 4; y(2) = 20; y(3) = 16; y(4) = 25;
  
  buildakimaspline(x, y, n, c1); 
  buildcubicspline(x, y, n, 0, 0, 0, 0, c2);
  buildlinearspline(x, y, n, c3);

  for(double x0 = 1; x0 < 5; x0 += 0.1)
    printf("%10.6lf, %10.6lf, %10.6lf, %10.6lf\n", x0, splineinterpolation(c1, x0), splineinterpolation(c2, x0), splineinterpolation(c3, x0));

  return 0;
}
